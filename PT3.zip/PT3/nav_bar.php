<nav class="navbar nav-tabs">
  <ul class="nav nav-tabs">
    <li>
      <a href="index.php">Home</a>
    </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown">Products
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="products.php">Add Product</a></li>
          <li><a href="products_details.php">Database</a></li>
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown">HR
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="customers.php">Customer</a></li>
          <li><a href="staffs.php">Staff</a></li>
        </ul>
      </li>
    <li><a href="orders.php">Order</a></li>
  </ul>
</nav>