<?php
/*
$servername = "lrgs.ftsm.ukm.my";
$username = "a197547";
$password = "littleyellowcat";
$dbname = "a197547";
 */
$servername = "localhost:3308";
$username = "root";
$password = "admin";
$dbname = "a197547";
?>