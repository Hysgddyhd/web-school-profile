<?php 
  include_once("customers_crud.php");
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My Bike Ordering System : Customers</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <nav class="navbar nav-tabs">
    <ul class="nav nav-tabs">
      <li>
        <a href="index.php">Home</a>
      </li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown">Products
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="products.php">Add Product</a></li>
            <li><a href="products_details.php">Database</a></li>
          </ul>
        </li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown">HR
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li class="active"><a href="customers.php">Customer</a></li>
            <li><a href="staffs.php">Staff</a></li>
          </ul>
        </li>
      <li><a href="orders.php">Order</a></li>
    </ul>
  </nav>
  
    <form action="customers.php" method="post">
      Customer ID
      <input name="cid" type="text" value="<?php if (isset($_GET['edit'])) echo $editRow['fld_customer_num'] ?>"> <br>
      First Name
      <input name="fname" type="text" value='<?php if (isset($_GET['edit'])) echo $editRow['fld_customer_fname'] ?>'> <br>
      Last Name
      <input name="lname" type="text" value='<?php if (isset($_GET['edit'])) echo $editRow['fld_customer_lname'] ?>'> <br>
      Gender
      <input name="gender" type="radio" value="Male" <?php if(isset($_GET['edit'])) if(strcmp($editRow['fld_customer_gender'], "Male")==0) echo "checked"; ?>> Male
      <input name="gender" type="radio" value="Female" <?php if(isset($_GET['edit'])) if(strcmp($editRow['fld_customer_gender'], "Female")==0) echo "checked"; ?>> Female <br>
      Birthday
      <input type="date" name="birthday" value="<?php if (isset($_GET['edit'])) echo $editRow['fld_customer_birthday'] ?>"><br>
      Phone Number
      <input name="phone" type="text" value='<?php if (isset($_GET['edit'])) echo $editRow['fld_customer_phone'] ?>'> <br>
      <?php if (isset($_GET['edit'])) { ?>
      <input type="hidden" name="oldcid" value="<?php echo $editRow['fld_customer_num']; ?>">
      <button type="submit" name="update">Update</button>
      <?php } else { ?>
      <button type="submit" name="create">Create</button>
      <?php } ?>      <button type="reset">Clear</button>
    </form>
    <hr>
    <table border="1">
      <tr>
        <td>Customer ID</td>
        <td>First Name</td>
        <td>Last Name</td>
        <td>Gender</td>
        <td>Birthday</td>
        <td>Phone Number</td>
        <td></td>
      </tr>
      <?php  
        try {
          $conn=new PDO("mysql:host=$servername;dbname=$dbname",$username,$password);
          $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
          $stmt=$conn->prepare("select * from tbl_customers_a197547_pt2");
          $stmt->execute();
          $result=$stmt->fetchAll();
        }
        catch(PDOException $e){
          echo $e;
        }
        foreach ($result as $cus) {
          // code...
        
      ?>
      <tr>
        <td><?php echo $cus['fld_customer_num'] ?></td>
        <td><?php echo $cus['fld_customer_fname'] ?></td>
        <td><?php echo $cus['fld_customer_lname'] ?></td>
        <td><?php echo $cus['fld_customer_gender'] ?></td>
        <td><?php echo $cus['fld_customer_birthday']; ?></td>
        <td><?php echo $cus['fld_customer_phone'] ?></td>
        <td>
          <a href="customers.php?edit=<?php echo $cus["fld_customer_num"] ?>">Edit</a>
          <a href="customers.php?delete=<?php echo $cus['fld_customer_num'] ?>">Delete</a>
        </td>
        </tr>
        <?php  
          }
          $conn=null;
        ?>
      </tr>
    </table>
</body>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</html>

